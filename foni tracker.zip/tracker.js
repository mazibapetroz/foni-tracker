document.addEventListener("DOMContentLoaded", () => {
  const trackingBtn = document.getElementById("track-btn");
  const trackingInfo = document.getElementById("tracking-info");
  const loading = document.getElementById("loading");
  const mapContainer = document.getElementById("map");
  const aboutBox = document.getElementById("location-box");
  let geoWatcherId = null;

  trackingBtn.addEventListener("click", async (event) => {
    event.preventDefault();
    const phoneNumber = document.getElementById("tracking-number").value.trim();
    const saNumberPattern = /^((\+27|0)[6-8][0-9]{8})$/;

    loading.style.display = "block";
    trackingInfo.style.display = "none";

    if (!saNumberPattern.test(phoneNumber)) {
      showError("Invalid South African phone number.");
      return;
    }

    const locationData = {};
    const deviceInfo = { lastUpdated: new Date().toLocaleString() };

    if (!("geolocation" in navigator)) {
      showError("Geolocation is not supported on this device.");
      return;
    }

    const confirmTracking = confirm("Enable live location tracking?");
    if (!confirmTracking) {
      showError("Tracking was cancelled by the user.");
      return;
    }

    geoWatcherId = navigator.geolocation.watchPosition(
      (position) => {
        Object.assign(locationData, {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          method: "GPS Live Tracking",
        });

        deviceInfo.lastUpdated = new Date().toLocaleString();
        localStorage.setItem("lastKnownLocation", JSON.stringify(locationData));

        updateTrackingInfo(phoneNumber, "Active", locationData, deviceInfo);
        loadMap(locationData.latitude, locationData.longitude);
        loading.style.display = "none";

        // Stop after one update (unless persistent tracking needed)
        navigator.geolocation.clearWatch(geoWatcherId);
      },
      async () => {
        try {
          const res = await fetch("https://ip-api.com/json");
          const data = await res.json();

          Object.assign(locationData, {
            city: data.city,
            country: data.country,
            method: "IP-based tracking",
          });

          updateTrackingInfo(phoneNumber, "Active", locationData, deviceInfo);
        } catch {
          showError("Unable to track phone location.");
        } finally {
          loading.style.display = "none";
        }
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  });

  function showError(message) {
    loading.style.display = "none";
    trackingInfo.style.display = "block";
    trackingInfo.innerHTML = `<p style='color: red;'>${message}</p>`;
  }

  function updateTrackingInfo(phoneNumber, status, location, device) {
    trackingInfo.style.display = "block";
    trackingInfo.innerHTML = `
      <p><strong>Phone Number:</strong> ${phoneNumber}</p>
      <p><strong>Status:</strong> ${status}</p>
      <p><strong>Last Updated:</strong> ${device.lastUpdated}</p>
      <p><strong>Location:</strong> ${
        status === "Active"
          ? location.method === "GPS Live Tracking"
            ? `Lat: ${location.latitude}, Lon: ${location.longitude}`
            : `${location.city}, ${location.country}`
          : "Unknown"
      }</p>
      <p><strong>Tracking Method:</strong> ${location.method}</p>
    `;
  }

  function loadMap(lat, lon) {
    mapContainer.style.display = "block";
    mapContainer.innerHTML = `<iframe width="100%" height="300"
      src="https://maps.google.com/maps?q=${lat},${lon}&output=embed" loading="lazy">
    </iframe>`;
  }
});
