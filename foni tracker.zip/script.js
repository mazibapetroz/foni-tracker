// db.js - Handles storing tracking history
const dbName = "TrackingDB";
const storeName = "history";

function openDB() {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open(dbName, 1);
        request.onupgradeneeded = () => {
            const db = request.result;
            if (!db.objectStoreNames.contains(storeName)) {
                db.createObjectStore(storeName, { keyPath: "timestamp" });
            }
        };
        request.onerror = () => reject("DB failed to open");
        request.onsuccess = () => resolve(request.result);
    });
}

async function saveTrackingLog(log) {
    const db = await openDB();
    const tx = db.transaction(storeName, "readwrite");
    tx.objectStore(storeName).add(log);
    return tx.complete;
}

async function loadTrackingHistory(callback) {
    const db = await openDB();
    const tx = db.transaction(storeName, "readonly");
    const store = tx.objectStore(storeName);
    const request = store.getAll();
    request.onsuccess = () => callback(request.result);
}
function sendEmailAlert(phone, location) {
    console.log(`Email alert: Tracking for ${phone} at ${location.latitude || location.city}`);
    // Actual backend implementation could POST to an email API
}

function sendSMSAlert(phone) {
    console.log(`SMS alert: Device for ${phone} is active.`);
}
